//  main.swift
//  BitRusty2023d
//  Created by SDBX.

import Foundation
import BigInt

print("Hello, World!")
print()
let SERIES_FLUSH:   [UInt8] = Array(0x00...0xFF);

let shuffledSeries: [UInt8] = Array(0x00...0xFF).shuffled();
print(shuffledSeries, shuffledSeries.count);

func funkyFunc() -> BigUInt {
    var seriesFlush = SERIES_FLUSH;
    var bigNum: BigUInt = 0;
    for x in 0..<shuffledSeries.count {
        let val = shuffledSeries[x];
        let idx = seriesFlush.firstIndex(of: val)!;
        seriesFlush.remove(at: idx);
        let BASE = seriesFlush.count;
        bigNum += BigUInt(idx);
        if (x < shuffledSeries.count - 1) {
            bigNum *= BigUInt(BASE);
        }
        assert(idx <= BASE);
    }
    return bigNum;
}
let bigNum = funkyFunc();
print()
print("Storage Space Required:", bigNum.bitWidth, "bits.")
print()
func reverseFunkyFunc(inputBigNum: BigUInt, length: Int) -> [UInt8] {
    var seriesFlush = SERIES_FLUSH;
    var shadowBigNum = inputBigNum;
    var indexBuilder: [UInt8] = []
    var originals: [UInt8] = []
    for x: BigUInt in 1...BigUInt(length) {
        let (quo, rem) = shadowBigNum.quotientAndRemainder(dividingBy: x)
        indexBuilder.append(UInt8(rem));
        shadowBigNum = quo;
    }
    indexBuilder.reverse();
    // WORKS [OK]: print(indexBuilder, indexBuilder.count)
    for x in 0..<indexBuilder.count {
        let idx: Int = Int(indexBuilder[x]);
        let val = seriesFlush[idx];
        seriesFlush.remove(at: idx);
        originals.append(val);
    }
    print(originals, originals.count);
    return originals;
}
let backToOriginals = reverseFunkyFunc(inputBigNum: bigNum, length: 256)

func perfectMatch(compareA: [UInt8], compareB: [UInt8]) -> Bool {
    var perfect = false;
    if (compareA.count == compareB.count) {
        for cmp in 0..<compareA.count {
            if (compareA[cmp] != compareB[cmp]) {
                perfect = false;
                print("Comparison Arrays: Mismatched Data.");
                return perfect;
            }
        }
        perfect = true;
        print("Comparison Arrays: PERFECT MATCH.")
        return perfect;
    } else {
        perfect = false;
        print("Comparison Arrays: Differ in Size/Length/Count.");
        return perfect;
    }
    return perfect; // Will never be executed [OK].
}
print()
print("PERFECT MATCH:", perfectMatch(compareA: shuffledSeries, compareB: backToOriginals));
print()
print("Goodbye......")
